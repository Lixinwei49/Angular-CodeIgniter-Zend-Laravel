Base
====

Base comprises of Normalize.css - a modern, HTML5-ready alternative to CSS
resets.

This component is a port of the original Normalize.css project, which can be
found at <http://necolas.github.com/normalize.css/>.


Differences
-----------

Changes are minimal. Base uses Normalize v1.1.1.

  - Create a contextual normalize.css (normalize-context.css) toggled off a
    parent classname: `.pure`.
