google-code-prettify-lite
=========================

Unofficial github mirror of the the google code prettify lib with all the fluff cut out. Added component.json file for bower integration