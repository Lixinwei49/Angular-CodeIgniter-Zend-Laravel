# Bootstrap


This is a Bower component for [Bootstrap 3](http://getbootstrap.com/) CSS library (v3.0.0).

## Installation:

`bower install bootstrap-css`


## Bootstrap 2.3 versions are available as well:

```
bower install bootstrap-css#2.3.2
bower install bootstrap-css#2.3.1
bower install bootstrap-css#2.3.0
```
