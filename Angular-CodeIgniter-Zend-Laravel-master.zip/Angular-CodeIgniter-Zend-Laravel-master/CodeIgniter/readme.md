CodeIgniter-Angular
===================

Project made in CodeIgniter framework and Angularjs and Kendo UI


Version 1.0.0