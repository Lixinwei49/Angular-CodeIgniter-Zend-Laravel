Comparation between CodeIgniter, Zend Framework and Laravel.
===============

<br>This repository will have a module with a Grid with persons, with the funtions to add, delete and update the data.

<br>
## The modules will have the next libraries.

 - <a href="http://angularjs.org/">Angular</a>
 - <a href="http://jquery.com/">Jquery</a>
 - <a href="http://getbootstrap.com/">Bootstrap-css</a>
 - <a href="https://github.com/angular-ui/bootstrap">Angular-bootstrap</a>
 - <a href="https://github.com/kendo-labs/angular-kendo">Angular-kendo-ui</a>
 - <a href="https://github.com/rstacruz/nprogress">Nprogress</a>
 - <a href="https://github.com/HubSpot/messenger">Messenger</a>


### Version 1.0
 - Basic module Release